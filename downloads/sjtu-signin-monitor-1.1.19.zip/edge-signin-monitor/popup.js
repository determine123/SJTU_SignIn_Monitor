const fields=['enabled','autoOpen','interval','firstActive','sound','pushplus_token','serverchan_sendkey','telegram_bot_token','telegram_chat_id'];const $=id=>document.getElementById(id);
async function render(){const {settings={},states={},logs=[]}=await chrome.storage.local.get(['settings','states','logs']);for(const k of fields){if(settings[k]!==undefined){if($(k).type==='checkbox')$(k).checked=settings[k];else $(k).value=settings[k];}}if(settings.courses)$('courses').value=settings.courses.join('\n');
 $('states').replaceChildren();for(const id of(settings.courses||['95353','95328','96927'])){const div=document.createElement('div');div.className='entry';const a=document.createElement('a');a.href=`https://oc.sjtu.edu.cn/courses/${id}/external_tools/6650`;a.target='_blank';a.textContent='课程 '+id;div.append(a,document.createTextNode(' · '+(states[id]?.status||'尚未检测')));const small=document.createElement('div');small.className='small';small.textContent=states[id]?.lastCheck?'最后识别：'+new Date(states[id].lastCheck).toLocaleString():'按自动打开设置等待课程页面';div.append(small);$('states').append(div);}
 $('logs').replaceChildren();for(const log of logs.slice(0,15)){const div=document.createElement('div');div.className='entry';div.textContent=new Date(log.time).toLocaleString()+' · '+(log.course?'课程 '+log.course+' · ':'')+log.message;$('logs').append(div);}}
$('save').onclick=async()=>{try{const s={courses:$('courses').value.split(/[\s,，]+/).filter(Boolean)};if(!s.courses.length||s.courses.some(v=>!/^\d+$/.test(v)))throw Error('请填写纯数字课程编号');for(const k of fields)s[k]=$(k).type==='checkbox'?$(k).checked:$(k).value.trim();const origins=[];if(s.pushplus_token)origins.push('https://www.pushplus.plus/*');if(s.serverchan_sendkey)origins.push('https://sctapi.ftqq.com/*');if(s.telegram_bot_token)origins.push('https://api.telegram.org/*');if(origins.length&&!await chrome.permissions.request({origins}))throw Error('手机推送访问权限未授权');const r=await chrome.runtime.sendMessage({type:'save',settings:s});if(!r.ok)throw Error(r.error);$('result').textContent='已保存；'+(s.enabled?'监控已启用':'监控已暂停');await render();}catch(e){$('result').textContent=e.message}};
for(const [id,type] of [['test','test'],['ack','ack']])$(id).onclick=async()=>{try{const r=await chrome.runtime.sendMessage({type});$('result').textContent=r.ok?(type==='test'?'已触发测试，请检查通知和手机':(r.audioStopped===false?'通知已清除，但声音停止失败；请查看日志':'提醒已停止')):r.error;await render();}catch(e){$('result').textContent=e.message}};
$('export').onclick=async()=>{const {logs=[]}=await chrome.storage.local.get('logs');const url=URL.createObjectURL(new Blob([JSON.stringify(logs,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='signin-events.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
async function renderClasses(){const {classSchedule=[],classEnabled=true,classDue={}}=await chrome.storage.local.get(['classSchedule','classEnabled','classDue']);$('classEnabled').checked=classEnabled;$('classJson').value=JSON.stringify(classSchedule,null,2);$('classRows').replaceChildren();for(const [i,r] of classSchedule.entries()){const box=document.createElement('div');box.className='entry';const title=document.createElement('strong');title.textContent=r.name+' · 周'+r.days.map(d=>'一二三四五六日'[d-1]).join('、')+' '+r.time+' · '+(r.location||'');box.append(title);for(const [field,label,type] of [['time','上课时间','time'],['from','起始日期','date'],['to','结束日期','date']]){const l=document.createElement('label');l.textContent=label;const input=document.createElement('input');input.type=type;input.value=r[field];input.dataset.row=i;input.dataset.field=field;box.append(l,input);}const small=document.createElement('div');small.className='small';const due=classDue['class:'+i];small.textContent=due?'下次提醒：'+new Date(due.when).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'}):'当前无待提醒课程';box.append(small);const remove=document.createElement('button');remove.type='button';remove.textContent='移除课程提醒';remove.setAttribute('aria-label','移除 '+r.name+' 的课程提醒');remove.onclick=async()=>{remove.disabled=true;try{const response=await chrome.runtime.sendMessage({type:'removeClass',index:i,row:r});if(!response.ok)throw Error(response.error);$('classResult').textContent='课程已移除，未来提醒已取消';await renderClasses();}catch(e){$('classResult').textContent=e.message;remove.disabled=false;}};box.append(remove);$('classRows').append(box);}}
async function saveClasses(advanced){try{let rows=JSON.parse($('classJson').value);if(!advanced)for(const input of $('classRows').querySelectorAll('input'))rows[Number(input.dataset.row)][input.dataset.field]=input.value;const response=await chrome.runtime.sendMessage({type:'saveClasses',rows,enabled:$('classEnabled').checked});if(!response.ok)throw Error(response.error);$('classResult').textContent='课表已保存（北京时间，提前 30 分钟）';await renderClasses();}catch(e){$('classResult').textContent=e.message;}}
$('saveClasses').onclick=()=>saveClasses(false);$('importClasses').onclick=()=>saveClasses(true);
$('openLiveQr').onclick=async event=>{
 event.preventDefault();
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
 const page=new URL(chrome.runtime.getURL('live-qr.html'));
 if(tab?.id!==undefined)page.searchParams.set('liveTab',String(tab.id));
 await chrome.tabs.create({url:page.href});
};
$('catchUpLive').onclick=async()=>{
 const result=$('catchUpResult');
 $('catchUpLive').disabled=true;
 result.textContent='正在检查直播播放器…';
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  result.textContent=await chrome.tabs.sendMessage(tab.id,{type:'catchUpLive'}) ||
   '请在正在播放的交大直播标签页中使用。';
 }catch{
  result.textContent='请刷新并播放交大直播标签页，再试一次。';
 }finally{
  $('catchUpLive').disabled=false;
 }
};
(async()=>{try{const r=await chrome.runtime.sendMessage({type:'activate'});if(!r.ok)throw Error(r.error);await render();await renderClasses();}catch(e){$('result').textContent='启用失败：'+e.message;}})();

$('lessonForm').onsubmit=async event=>{event.preventDefault();try{const row=ClassSchedule.fromForm({name:$('lessonName').value,courseId:$('lessonCourse').value.trim(),day:$('lessonDay').value,time:$('lessonTime').value,from:$('lessonFrom').value,to:$('lessonTo').value,location:$('lessonLocation').value.trim()});const {classSchedule=[]}=await chrome.storage.local.get('classSchedule');const response=await chrome.runtime.sendMessage({type:'saveClasses',rows:[...classSchedule,row],enabled:$('classEnabled').checked});if(!response.ok)throw Error(response.error);$('classResult').textContent='课程已添加';$('lessonForm').reset();await renderClasses();}catch(e){$('classResult').textContent=e.message;}};
